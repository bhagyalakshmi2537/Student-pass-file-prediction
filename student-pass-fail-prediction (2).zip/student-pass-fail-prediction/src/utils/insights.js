import { RAW_FEATURE_COLUMNS } from './featureEngineering'

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

function pearsonCorrelation(x, y) {
  const n = x.length
  const meanX = avg(x)
  const meanY = avg(y)
  let num = 0, sumSqX = 0, sumSqY = 0
  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX
    const dy = y[i] - meanY
    num += dx * dy
    sumSqX += dx * dx
    sumSqY += dy * dy
  }
  const denom = Math.sqrt(sumSqX * sumSqY)
  return denom === 0 ? 0 : num / denom
}

/** Generates dynamic, dataset-derived observations — never hardcoded claims. */
export function generateDatasetInsights(students, summary) {
  const insights = []

  insights.push(`Overall pass percentage in this dataset is ${summary.passPercentage.toFixed(1)}%, with a fail percentage of ${summary.failPercentage.toFixed(1)}%.`)
  insights.push(`Average attendance is ${summary.averageAttendance.toFixed(1)}% and average study time is ${summary.averageStudyHours.toFixed(1)} hours per day.`)

  const target = students.map((s) => (s.final_result === 'pass' ? 1 : 0))
  const correlations = RAW_FEATURE_COLUMNS.map((col) => ({
    feature: col,
    correlation: pearsonCorrelation(students.map((s) => s[col]), target),
  }))
  const strongest = [...correlations].sort((a, b) => Math.abs(b.correlation) - Math.abs(a.correlation))[0]
  if (strongest) {
    const direction = strongest.correlation >= 0 ? 'positively' : 'negatively'
    insights.push(`${formatFeatureName(strongest.feature)} shows the strongest observed association with outcome in this dataset (${direction} correlated, r = ${strongest.correlation.toFixed(2)}). This is a dataset pattern, not proof of causation.`)
  }

  return insights
}

function formatFeatureName(col) {
  return col.split('_').map((w) => w[0].toUpperCase() + w.slice(1)).join(' ')
}

/** Adds model-comparison and misclassification insights once both models have been trained. */
export function generateModelInsights(models) {
  const insights = []
  const entries = Object.values(models)
  if (entries.length >= 2) {
    const best = [...entries].sort((a, b) => b.metrics.f1 - a.metrics.f1)[0]
    insights.push(`${best.label} achieved the highest F1 score among the evaluated models (${(best.metrics.f1 * 100).toFixed(1)}%).`)
  }

  entries.forEach((m) => {
    const { fp, fn } = m.metrics.confusionMatrix
    if (fp === fn) return
    const type = fp > fn ? 'students predicted to pass who actually failed' : 'students predicted to fail who actually passed'
    insights.push(`For ${m.label}, the most common misclassification is ${type}.`)
  })

  return insights
}
