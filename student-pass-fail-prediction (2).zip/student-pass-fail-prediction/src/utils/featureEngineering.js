import { median } from '../services/dataset'

// Student ID and the target itself are deliberately excluded — using either
// as a model input would be target leakage.
export const RAW_FEATURE_COLUMNS = [
  'attendance', 'study_hours', 'internal_marks', 'assignment_score',
  'previous_exam_score', 'midterm_score', 'participation', 'sleep_hours',
]
export const FEATURE_COLUMNS = [...RAW_FEATURE_COLUMNS, 'academic_average', 'study_engagement']

/** Computes median imputation values from valid (non-missing) records only. */
export function computeImputationStats(rows) {
  const stats = {}
  RAW_FEATURE_COLUMNS.forEach((col) => {
    const valid = rows.filter((r) => typeof r[col] === 'number' && !Number.isNaN(r[col])).map((r) => r[col])
    stats[col] = valid.length ? median(valid) : 0
  })
  return stats
}

/** Cleans one student record: imputes missing values, adds engineered features. */
export function engineerStudent(row, imputation) {
  const student = { student_id: row.student_id, age: row.age, gender: row.gender, final_result: row.final_result }

  RAW_FEATURE_COLUMNS.forEach((col) => {
    student[col] = (typeof row[col] === 'number' && !Number.isNaN(row[col])) ? row[col] : imputation[col]
  })

  student.academic_average = (
    student.internal_marks + student.assignment_score + student.previous_exam_score + student.midterm_score
  ) / 4

  const studyHoursNormalized = Math.min(student.study_hours / 8, 1) * 100
  student.study_engagement = (studyHoursNormalized + student.participation + student.attendance) / 3

  return student
}

export function engineerDataset(rows) {
  const imputation = computeImputationStats(rows)
  const students = rows.map((r) => engineerStudent(r, imputation))
  return { students, imputation }
}

export function featureVector(student) {
  return FEATURE_COLUMNS.map((col) => student[col])
}

/** Builds a full engineered student record from a prediction form's raw input (no missing values expected). */
export function engineerFormInput(input) {
  return engineerStudent({ student_id: 'new', age: null, gender: null, final_result: null, ...input }, {})
}
