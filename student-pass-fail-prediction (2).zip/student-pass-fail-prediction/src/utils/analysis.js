const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0)

const ATTENDANCE_RANGES = [
  { label: '0-50%', min: 0, max: 50 },
  { label: '51-60%', min: 51, max: 60 },
  { label: '61-70%', min: 61, max: 70 },
  { label: '71-80%', min: 71, max: 80 },
  { label: '81-90%', min: 81, max: 90 },
  { label: '91-100%', min: 91, max: 100 },
]

const STUDY_HOUR_RANGES = [
  { label: '0-2 hrs', min: 0, max: 2 },
  { label: '2-4 hrs', min: 2, max: 4 },
  { label: '4-6 hrs', min: 4, max: 6 },
  { label: '6-8 hrs', min: 6, max: 8 },
  { label: '8+ hrs', min: 8, max: Infinity },
]

function bucketAnalysis(students, ranges, field) {
  return ranges.map(({ label, min, max }) => {
    const inBucket = students.filter((s) => s[field] >= min && s[field] < (max === Infinity ? Infinity : max + (max === 100 ? 0.001 : 0)))
    const passCount = inBucket.filter((s) => s.final_result === 'pass').length
    return {
      range: label,
      studentCount: inBucket.length,
      passCount,
      failCount: inBucket.length - passCount,
      passPercentage: inBucket.length ? (passCount / inBucket.length) * 100 : 0,
    }
  })
}

export function attendanceRangeAnalysis(students) {
  return bucketAnalysis(students, ATTENDANCE_RANGES, 'attendance')
}

export function studyHoursRangeAnalysis(students) {
  return bucketAnalysis(students, STUDY_HOUR_RANGES, 'study_hours')
}

/** Passed vs failed averages for the four core academic scores. */
export function academicComparisonByResult(students) {
  const passed = students.filter((s) => s.final_result === 'pass')
  const failed = students.filter((s) => s.final_result === 'fail')

  const fields = ['internal_marks', 'assignment_score', 'previous_exam_score', 'midterm_score']
  return fields.map((field) => ({
    field,
    label: field.split('_').map((w) => w[0].toUpperCase() + w.slice(1)).join(' '),
    passed: Number(avg(passed.map((s) => s[field])).toFixed(1)),
    failed: Number(avg(failed.map((s) => s[field])).toFixed(1)),
  }))
}

export function attendanceCategory(attendance) {
  if (attendance >= 91) return 'Excellent'
  if (attendance >= 81) return 'Good'
  if (attendance >= 71) return 'Fair'
  if (attendance >= 61) return 'Low'
  return 'Critical'
}
