import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

const APP_NAME = 'Student Pass/Fail Prediction Report'

/**
 * Builds and downloads a PDF student pass/fail analysis report.
 * chartElement is an optional DOM node captured as an image and embedded
 * in the PDF. If capture fails, the report still generates without it.
 */
export async function generateStudentReportPdf({
  summary, trainingResult, modelKey, prediction, insights, chartElement,
}) {
  if (!summary) {
    throw new Error('Please load the student dataset first.')
  }
  if (!trainingResult) {
    throw new Error('Train the model before generating the report.')
  }

  const model = trainingResult.models[modelKey]

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const margin = 48
  let y = margin

  const ensureSpace = (needed) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
  }

  const line = (text, size = 11, weight = 'normal', gap = 16) => {
    ensureSpace(gap)
    doc.setFont('helvetica', weight)
    doc.setFontSize(size)
    doc.text(text, margin, y)
    y += gap
  }

  // Cover
  doc.setFillColor(24, 36, 54)
  doc.rect(0, 0, pageWidth, 90, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(17)
  doc.text(APP_NAME, margin, 32)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.text(`Report generated: ${new Date().toLocaleString()}`, margin, 50)
  doc.text(`Dataset: student_results.csv  |  Model: ${model.label}  |  Split: ${trainingResult.trainingSamples}/${trainingResult.testingSamples} (train/test)`, margin, 66)
  doc.setTextColor(24, 36, 54)
  y = 118

  // Dataset summary
  line('Dataset Summary', 13, 'bold', 20)
  line(`Total Students: ${summary.totalStudents}`)
  line(`Passed Students: ${summary.passedCount}`)
  line(`Failed Students: ${summary.failedCount}`)
  line(`Pass Percentage: ${summary.passPercentage.toFixed(1)}%`)
  line(`Fail Percentage: ${summary.failPercentage.toFixed(1)}%`)
  line(`Average Attendance: ${summary.averageAttendance.toFixed(1)}%`)
  line(`Average Study Hours: ${summary.averageStudyHours.toFixed(1)} hrs/day`)
  y += 8

  // Model performance
  line('Model Performance', 13, 'bold', 20)
  Object.values(trainingResult.models).forEach((m) => {
    line(`${m.label}: Accuracy ${(m.metrics.accuracy * 100).toFixed(1)}%, Precision ${(m.metrics.precision * 100).toFixed(1)}%, Recall ${(m.metrics.recall * 100).toFixed(1)}%, F1 ${(m.metrics.f1 * 100).toFixed(1)}%, ROC-AUC ${m.metrics.rocAuc.toFixed(3)}`, 10)
  })
  y += 8

  const cm = model.metrics.confusionMatrix
  line(`Confusion Matrix (${model.label})`, 12, 'bold', 16)
  line(`True Positive (Pass): ${cm.tp}   True Negative (Fail): ${cm.tn}   False Positive: ${cm.fp}   False Negative: ${cm.fn}`, 10)
  y += 8

  // Current prediction
  line('Prediction Details', 13, 'bold', 20)
  if (prediction) {
    line(`Model Used: ${prediction.modelLabel}`)
    line(`Attendance: ${prediction.input.attendance}%, Study Hours: ${prediction.input.study_hours} hrs/day, Sleep Hours: ${prediction.input.sleep_hours} hrs`)
    line(`Internal Marks: ${prediction.input.internal_marks}, Assignment: ${prediction.input.assignment_score}, Previous Exam: ${prediction.input.previous_exam_score}, Midterm: ${prediction.input.midterm_score}`)
    line(`Academic Average: ${prediction.input.academic_average.toFixed(1)}`)
    line(`Pass Probability: ${(prediction.probability * 100).toFixed(1)}%`)
    line(`Fail Probability: ${((1 - prediction.probability) * 100).toFixed(1)}%`)
    line(`Prediction: ${prediction.willPass ? 'Likely to Pass' : 'Likely to Fail'}`)
    line(`Interpretation: ${prediction.interpretation}`)
  } else {
    line('No individual prediction was generated.')
  }
  y += 8

  // Insights
  if (insights && insights.length) {
    line('Insights', 13, 'bold', 20)
    insights.forEach((text) => {
      const wrapped = doc.splitTextToSize(`• ${text}`, pageWidth - margin * 2)
      ensureSpace(wrapped.length * 14 + 4)
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(10)
      doc.text(wrapped, margin, y)
      y += wrapped.length * 14 + 4
    })
    y += 8
  }

  // Chart (best effort)
  if (chartElement) {
    try {
      const canvas = await html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height / canvas.width) * imgWidth

      ensureSpace(imgHeight + 24)
      line('Visualization', 13, 'bold', 20)
      doc.addImage(imgData, 'PNG', margin, y, imgWidth, imgHeight)
      y += imgHeight + 10
    } catch (err) {
      line('Chart could not be rendered for this report.', 10, 'italic')
    }
  }

  doc.save('student-pass-fail-prediction-report.pdf')
}
