import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import ModelMetrics from '../components/ModelMetrics'
import ConfusionMatrix from '../components/ConfusionMatrix'

export default function ModelPerformance({ trainingResult, modelKey, onModelChange }) {
  if (!trainingResult) {
    return (
      <div className="bg-white rounded-lg border border-black/5 p-8 text-center text-ink/50">
        Training model, results will appear here shortly.
      </div>
    )
  }

  const model = trainingResult.models[modelKey]
  const models = Object.entries(trainingResult.models)
  const betterModel = [...models].sort((a, b) => b[1].metrics.f1 - a[1].metrics.f1)[0]

  const importanceData = model.type === 'decision-tree'
    ? model.featureImportance.map((f) => ({ feature: f.feature, value: f.importance }))
    : model.coefficients
        .map((c) => ({ feature: c.feature, value: Math.abs(c.weight), signed: c.weight }))
        .sort((a, b) => b.value - a.value)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-black/5 p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <p className="text-sm text-ink/70 font-medium">Model shown below</p>
        <select
          value={modelKey}
          onChange={(e) => onModelChange(e.target.value)}
          className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="logistic-regression">Logistic Regression</option>
          <option value="decision-tree">Decision Tree</option>
        </select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Training Samples" value={trainingResult.trainingSamples} />
        <StatCard label="Testing Samples" value={trainingResult.testingSamples} />
        <StatCard label="ROC-AUC" value={model.metrics.rocAuc.toFixed(3)} />
        <StatCard label="Threshold" value={model.metrics.threshold} />
      </div>

      <ModelMetrics metrics={model.metrics} label={model.label} />

      <div className="grid md:grid-cols-2 gap-5">
        <ConfusionMatrix matrix={model.metrics.confusionMatrix} />

        <ChartCard
          title={model.type === 'decision-tree' ? 'Feature Importance' : 'Feature Influence (Coefficients)'}
          description={model.type === 'decision-tree' ? 'Share of total impurity reduction per feature' : 'Absolute coefficient magnitude — not a causal claim'}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={importanceData} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#e7eaec" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="feature" tick={{ fontSize: 10 }} width={90} />
              <Tooltip />
              <Bar dataKey="value" fill="#3C5FA8" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="bg-white rounded-lg border border-black/5 p-5">
        <h3 className="text-sm font-medium text-ink mb-4">Model Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[560px]">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
                <th className="py-2 pr-4">Metric</th>
                {models.map(([key, m]) => (
                  <th key={key} className="py-2 pr-4">
                    {m.label}{betterModel[0] === key && models.length > 1 ? ' ★' : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {['accuracy', 'precision', 'recall', 'f1'].map((metricKey) => (
                <tr key={metricKey} className="border-b border-black/5 last:border-0">
                  <td className="py-2 pr-4 capitalize">{metricKey === 'f1' ? 'F1 Score' : metricKey}</td>
                  {models.map(([key, m]) => (
                    <td key={key} className="py-2 pr-4">{(m.metrics[metricKey] * 100).toFixed(1)}%</td>
                  ))}
                </tr>
              ))}
              <tr>
                <td className="py-2 pr-4">ROC-AUC</td>
                {models.map(([key, m]) => <td key={key} className="py-2 pr-4">{m.metrics.rocAuc.toFixed(3)}</td>)}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
