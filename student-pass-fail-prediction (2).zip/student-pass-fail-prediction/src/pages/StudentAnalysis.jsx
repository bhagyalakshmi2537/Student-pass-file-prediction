import React, { useMemo, useState } from 'react'
import { BarChart, Bar, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import StudentTable from '../components/StudentTable'
import StudentDetails from '../components/StudentDetails'
import { computeSummary } from '../services/dataset'
import { attendanceRangeAnalysis, studyHoursRangeAnalysis, academicComparisonByResult } from '../utils/analysis'

const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0)
const RESULT_COLOR = { pass: '#3C5FA8', fail: '#9A3B4A' }

export default function StudentAnalysis({ students }) {
  const [selected, setSelected] = useState(null)
  const summary = computeSummary(students)

  const passed = students.filter((s) => s.final_result === 'pass')
  const failed = students.filter((s) => s.final_result === 'fail')

  const academicByResult = useMemo(() => academicComparisonByResult(students), [students])
  const attendanceRanges = useMemo(() => attendanceRangeAnalysis(students), [students])
  const studyHourRanges = useMemo(() => studyHoursRangeAnalysis(students), [students])

  const factorCharts = [
    ['attendance', 'Attendance vs Result'],
    ['study_hours', 'Study Hours vs Result'],
    ['internal_marks', 'Internal Marks vs Result'],
    ['assignment_score', 'Assignment Score vs Result'],
    ['previous_exam_score', 'Previous Exam Score vs Result'],
    ['midterm_score', 'Midterm Score vs Result'],
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Students" value={summary.totalStudents} />
        <StatCard label="Pass Count" value={summary.passedCount} />
        <StatCard label="Fail Count" value={summary.failedCount} />
        <StatCard label="Average Attendance" value={`${summary.averageAttendance.toFixed(1)}%`} />
        <StatCard label="Average Study Hours" value={`${summary.averageStudyHours.toFixed(1)} hrs`} />
        <StatCard label="Average Internal Marks" value={summary.averageInternalMarks.toFixed(1)} />
        <StatCard label="Average Assignment Score" value={avg(students.map((s) => s.assignment_score)).toFixed(1)} />
        <StatCard label="Average Midterm Score" value={avg(students.map((s) => s.midterm_score)).toFixed(1)} />
      </div>

      <div className="bg-white rounded-lg border border-black/5 p-5">
        <h3 className="text-sm font-medium text-ink mb-1">Passed vs Failed — Academic Averages</h3>
        <p className="text-xs text-ink/40 mb-4">Dataset patterns — not evidence of causation</p>
        <div style={{ height: 240 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={academicByResult} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="passed" name="Passed" fill="#3C5FA8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="failed" name="Failed" fill="#9A3B4A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        {factorCharts.map(([key, title]) => (
          <ChartCard key={key} title={title}>
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
                <CartesianGrid stroke="#e6e9ee" />
                <XAxis type="category" dataKey="final_result" name="Result" tick={{ fontSize: 11 }} />
                <YAxis type="number" dataKey={key} name={title} tick={{ fontSize: 11 }} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter data={students}>
                  {students.map((s, i) => <Cell key={i} fill={RESULT_COLOR[s.final_result]} />)}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </ChartCard>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Attendance Analysis" description="Pass rate by attendance range">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={attendanceRanges} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="passPercentage" fill="#3C5FA8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Study Hours Analysis" description="Pass rate by study-hour range">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={studyHourRanges} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="passPercentage" fill="#C2933D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 min-w-0">
          <StudentTable students={students} onSelect={setSelected} selectedId={selected?.student_id} />
        </div>
        <StudentDetails student={selected} />
      </div>
    </div>
  )
}
