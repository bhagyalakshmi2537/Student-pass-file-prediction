import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary } from '../services/dataset'
import { attendanceRangeAnalysis, studyHoursRangeAnalysis, academicComparisonByResult } from '../utils/analysis'

function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}

export default function Dashboard({ students }) {
  const summary = computeSummary(students)

  const distribution = [
    { name: 'Pass', value: summary.passedCount },
    { name: 'Fail', value: summary.failedCount },
  ]

  const attendanceDist = useMemo(() => histogram(students.map((s) => s.attendance)), [students])
  const studyHoursDist = useMemo(() => histogram(students.map((s) => s.study_hours), 6), [students])
  const academicByResult = useMemo(() => academicComparisonByResult(students), [students])
  const attendanceRanges = useMemo(() => attendanceRangeAnalysis(students), [students])
  const studyHourRanges = useMemo(() => studyHoursRangeAnalysis(students), [students])

  const COLORS = ['#3C5FA8', '#9A3B4A']

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Students" value={summary.totalStudents} />
        <StatCard label="Passed Students" value={summary.passedCount} />
        <StatCard label="Failed Students" value={summary.failedCount} />
        <StatCard label="Pass Percentage" value={`${summary.passPercentage.toFixed(1)}%`} />
        <StatCard label="Fail Percentage" value={`${summary.failPercentage.toFixed(1)}%`} />
        <StatCard label="Average Attendance" value={`${summary.averageAttendance.toFixed(1)}%`} />
        <StatCard label="Average Study Hours" value={`${summary.averageStudyHours.toFixed(1)} hrs`} />
        <StatCard label="Average Internal Marks" value={summary.averageInternalMarks.toFixed(1)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Pass vs Fail Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={distribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {distribution.map((d, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Attendance Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={attendanceDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#3C5FA8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Study Hours Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={studyHoursDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#C2933D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Academic Scores by Result">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={academicByResult} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="passed" name="Passed" fill="#3C5FA8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="failed" name="Failed" fill="#9A3B4A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Pass Rate by Attendance Range">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={attendanceRanges} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="passPercentage" fill="#3C5FA8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Pass Rate by Study Hours">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={studyHourRanges} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e6e9ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="passPercentage" fill="#C2933D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
