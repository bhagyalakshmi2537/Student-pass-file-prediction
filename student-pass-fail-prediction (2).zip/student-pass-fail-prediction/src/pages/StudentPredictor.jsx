import React, { useRef, useState } from 'react'
import StudentForm from '../components/StudentForm'
import PredictionResult from '../components/PredictionResult'
import ReportButton from '../components/ReportButton'
import { engineerFormInput } from '../utils/featureEngineering'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights, generateModelInsights } from '../utils/insights'

function interpretProfile(input) {
  if (input.academic_average >= 70 && input.attendance >= 80) {
    return 'Strong Academic Profile — high marks and attendance.'
  }
  if (input.academic_average < 50 || input.attendance < 60) {
    return 'At-Risk Profile — lower academic indicators.'
  }
  return 'Moderate Academic Profile — mixed academic indicators.'
}

export default function StudentPredictor({ students, trainingResult, modelKey, onModelChange, status }) {
  const [result, setResult] = useState(null)
  const resultRef = useRef(null)

  const ready = status === 'ready' && trainingResult

  const handleSubmit = (rawInput) => {
    if (!ready) return
    const model = trainingResult.models[modelKey]
    const engineered = engineerFormInput(rawInput)
    const probability = model.predictProbability(engineered)
    const willPass = probability >= 0.5

    setResult({
      probability,
      willPass,
      threshold: 0.5,
      modelLabel: model.label,
      input: engineered,
      interpretation: interpretProfile(engineered),
    })
  }

  const summary = computeSummary(students)
  const insights = [...generateDatasetInsights(students, summary)]
  if (trainingResult) insights.push(...generateModelInsights(trainingResult.models))

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <StudentForm modelKey={modelKey} onModelChange={onModelChange} onSubmit={handleSubmit} disabled={!ready} />
        <PredictionResult result={result} innerRef={resultRef} />
      </div>

      {result && (
        <div className="flex justify-end">
          <ReportButton
            summary={summary}
            trainingResult={trainingResult}
            modelKey={modelKey}
            prediction={result}
            insights={insights}
            chartElement={resultRef.current}
          />
        </div>
      )}
    </div>
  )
}
