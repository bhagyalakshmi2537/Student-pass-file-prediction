import * as tf from '@tensorflow/tfjs'
import { FEATURE_COLUMNS } from '../utils/featureEngineering'
import { normalizedFeatureVector } from './preprocessing'

/**
 * Trains a logistic regression classifier (single dense unit + sigmoid,
 * binary cross-entropy loss) using TensorFlow.js. Target: 1 = pass, 0 = fail.
 */
export async function trainLogisticRegression(trainStudents, stats, { epochs = 60, onEpoch } = {}) {
  const xs = tf.tensor2d(trainStudents.map((s) => normalizedFeatureVector(s, stats)))
  const ys = tf.tensor2d(trainStudents.map((s) => [s.final_result === 'pass' ? 1 : 0]))

  const model = tf.sequential()
  model.add(tf.layers.dense({ inputShape: [FEATURE_COLUMNS.length], units: 1, activation: 'sigmoid' }))
  model.compile({ optimizer: tf.train.adam(0.05), loss: 'binaryCrossentropy', metrics: ['accuracy'] })

  await model.fit(xs, ys, {
    epochs,
    batchSize: 32,
    shuffle: true,
    verbose: 0,
    callbacks: {
      onEpochEnd: async (epoch) => {
        if (onEpoch) onEpoch(epoch + 1, epochs)
        await tf.nextFrame()
      },
    },
  })

  const [kernel, bias] = model.layers[0].getWeights()
  const weights = Array.from(kernel.dataSync())
  const biasValue = bias.dataSync()[0]

  xs.dispose()
  ys.dispose()

  const coefficients = FEATURE_COLUMNS.map((feature, i) => ({ feature, weight: weights[i] }))

  return {
    type: 'logistic-regression',
    label: 'Logistic Regression',
    model,
    coefficients,
    bias: biasValue,
    predictProbability: (student) => {
      const vector = normalizedFeatureVector(student, stats)
      const inputTensor = tf.tensor2d([vector])
      const outputTensor = model.predict(inputTensor)
      const prob = outputTensor.dataSync()[0]
      inputTensor.dispose()
      outputTensor.dispose()
      return prob
    },
  }
}
