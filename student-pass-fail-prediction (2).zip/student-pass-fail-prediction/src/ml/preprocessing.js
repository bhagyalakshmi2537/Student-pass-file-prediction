import { FEATURE_COLUMNS, featureVector } from '../utils/featureEngineering'

/** Shuffles and splits students into 80% train / 20% test, deterministically. */
export function trainTestSplit(students, testRatio = 0.2, seed = 42) {
  const shuffled = seededShuffle(students, seed)
  const testSize = Math.max(1, Math.round(shuffled.length * testRatio))
  const testSet = shuffled.slice(0, testSize)
  const trainSet = shuffled.slice(testSize)
  return { trainSet, testSet }
}

function seededShuffle(array, seed) {
  const result = [...array]
  let s = seed
  const random = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

/** Computes per-feature min/max from training students only. */
export function computeFeatureStats(students) {
  const stats = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = students.map((p) => p[col])
    stats[col] = { min: Math.min(...values), max: Math.max(...values) }
  })
  return stats
}

export function normalizeValue(value, min, max) {
  if (max === min) return 0
  return (value - min) / (max - min)
}

export function normalizedFeatureVector(student, stats) {
  return FEATURE_COLUMNS.map((col) => normalizeValue(student[col], stats[col].min, stats[col].max))
}

export { featureVector }
