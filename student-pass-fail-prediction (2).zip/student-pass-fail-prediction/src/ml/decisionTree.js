import { FEATURE_COLUMNS, featureVector } from '../utils/featureEngineering'

function gini(labels, indices) {
  if (indices.length === 0) return 0
  let positives = 0
  indices.forEach((i) => { if (labels[i] === 1) positives += 1 })
  const p = positives / indices.length
  return 1 - (p * p + (1 - p) * (1 - p))
}

function splitIndices(X, indices, featureIdx, threshold) {
  const left = []
  const right = []
  indices.forEach((i) => {
    if (X[i][featureIdx] <= threshold) left.push(i)
    else right.push(i)
  })
  return { left, right }
}

function findBestSplit(X, y, indices, minSamplesLeaf) {
  const parentGini = gini(y, indices)
  let best = null

  for (let f = 0; f < FEATURE_COLUMNS.length; f++) {
    const uniqueValues = [...new Set(indices.map((i) => X[i][f]))].sort((a, b) => a - b)
    for (let u = 0; u < uniqueValues.length - 1; u++) {
      const threshold = (uniqueValues[u] + uniqueValues[u + 1]) / 2
      const { left, right } = splitIndices(X, indices, f, threshold)
      if (left.length < minSamplesLeaf || right.length < minSamplesLeaf) continue

      const weightedGini = (left.length / indices.length) * gini(y, left)
        + (right.length / indices.length) * gini(y, right)
      const decrease = parentGini - weightedGini

      if (!best || decrease > best.decrease) {
        best = { featureIdx: f, threshold, left, right, decrease }
      }
    }
  }

  return best
}

function buildNode(X, y, indices, depth, maxDepth, minSamplesLeaf, importanceAcc) {
  const positives = indices.filter((i) => y[i] === 1).length
  const probability = positives / indices.length

  if (depth >= maxDepth || indices.length < minSamplesLeaf * 2 || probability === 0 || probability === 1) {
    return { isLeaf: true, probability, samples: indices.length }
  }

  const split = findBestSplit(X, y, indices, minSamplesLeaf)
  if (!split || split.decrease <= 0) {
    return { isLeaf: true, probability, samples: indices.length }
  }

  const featureName = FEATURE_COLUMNS[split.featureIdx]
  importanceAcc[featureName] = (importanceAcc[featureName] || 0) + split.decrease * indices.length

  return {
    isLeaf: false,
    featureIdx: split.featureIdx,
    feature: featureName,
    threshold: split.threshold,
    probability,
    samples: indices.length,
    left: buildNode(X, y, split.left, depth + 1, maxDepth, minSamplesLeaf, importanceAcc),
    right: buildNode(X, y, split.right, depth + 1, maxDepth, minSamplesLeaf, importanceAcc),
  }
}

function predictNode(node, vector) {
  if (node.isLeaf) return node.probability
  return vector[node.featureIdx] <= node.threshold ? predictNode(node.left, vector) : predictNode(node.right, vector)
}

/** Trains a CART-style decision tree classifier (Gini impurity) from scratch. */
export function trainDecisionTree(trainStudents, { maxDepth = 5, minSamplesLeaf = 8 } = {}) {
  const X = trainStudents.map((s) => featureVector(s))
  const y = trainStudents.map((s) => (s.final_result === 'pass' ? 1 : 0))
  const indices = trainStudents.map((_, i) => i)

  const importanceAcc = {}
  const tree = buildNode(X, y, indices, 0, maxDepth, minSamplesLeaf, importanceAcc)

  const totalImportance = Object.values(importanceAcc).reduce((a, b) => a + b, 0) || 1
  const featureImportance = FEATURE_COLUMNS
    .map((feature) => ({ feature, importance: (importanceAcc[feature] || 0) / totalImportance }))
    .sort((a, b) => b.importance - a.importance)

  return {
    type: 'decision-tree',
    label: 'Decision Tree',
    tree,
    maxDepth,
    featureImportance,
    predictProbability: (student) => predictNode(tree, featureVector(student)),
  }
}
