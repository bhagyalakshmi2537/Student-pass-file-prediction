import Papa from 'papaparse'

const REQUIRED_COLUMNS = ['attendance', 'study_hours', 'internal_marks', 'assignment_score', 'previous_exam_score', 'final_result']

const RANGES = {
  attendance: [0, 100],
  internal_marks: [0, 100],
  assignment_score: [0, 100],
  previous_exam_score: [0, 100],
  midterm_score: [0, 100],
  participation: [0, 100],
  study_hours: [0, 24],
  sleep_hours: [0, 24],
}

function normalizeResult(raw) {
  const v = String(raw || '').trim().toLowerCase()
  if (v === 'pass') return 'pass'
  if (v === 'fail') return 'fail'
  return null
}

function inRange(value, [min, max]) {
  return typeof value === 'number' && !Number.isNaN(value) && value >= min && value <= max
}

/** Loads and parses the student results dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/student_results.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Please load the student dataset first. (status ${response.status})`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const fields = parsed.meta.fields || []
  const missingColumns = REQUIRED_COLUMNS.filter((c) => !fields.includes(c))
  if (missingColumns.length > 0) {
    throw new Error(`Dataset is missing required columns: ${missingColumns.join(', ')}.`)
  }

  const seen = new Set()
  const rows = parsed.data.filter((row) => {
    const result = normalizeResult(row.final_result)
    if (!result) return false
    row.final_result = result

    // Range-validate every numeric field that's present (missing is handled
    // separately via imputation, not treated as invalid here).
    for (const [col, range] of Object.entries(RANGES)) {
      const value = row[col]
      const present = typeof value === 'number' && !Number.isNaN(value)
      if (present && !inRange(value, range)) return false
    }

    const key = row.student_id || JSON.stringify(row)
    if (seen.has(key)) return false // drop duplicate records
    seen.add(key)
    return true
  })

  if (rows.length < 100) {
    throw new Error('Dataset has too few valid student records to train a reliable model.')
  }

  const passCount = rows.filter((r) => r.final_result === 'pass').length
  if (passCount === 0 || passCount === rows.length) {
    throw new Error('Dataset contains only one outcome class — both Pass and Fail records are needed to train a model.')
  }

  return rows
}

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

export function computeSummary(students) {
  const passed = students.filter((s) => s.final_result === 'pass')
  const validAttendance = students.filter((s) => typeof s.attendance === 'number').map((s) => s.attendance)
  const validStudyHours = students.filter((s) => typeof s.study_hours === 'number').map((s) => s.study_hours)
  const validInternalMarks = students.filter((s) => typeof s.internal_marks === 'number').map((s) => s.internal_marks)

  return {
    totalStudents: students.length,
    passedCount: passed.length,
    failedCount: students.length - passed.length,
    passPercentage: (passed.length / students.length) * 100,
    failPercentage: ((students.length - passed.length) / students.length) * 100,
    averageAttendance: validAttendance.length ? avg(validAttendance) : 0,
    averageStudyHours: validStudyHours.length ? avg(validStudyHours) : 0,
    averageInternalMarks: validInternalMarks.length ? avg(validInternalMarks) : 0,
  }
}

export function median(values) {
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}
