import React from 'react'
import { attendanceCategory } from '../utils/analysis'

export default function StudentDetails({ student }) {
  if (!student) {
    return (
      <div className="bg-white rounded-lg border border-black/5 border-dashed p-6 text-center text-ink/40 text-sm">
        Select a student from the table to see their details.
      </div>
    )
  }

  const rows = [
    ['Student ID', student.student_id],
    ['Age', student.age ?? '—'],
    ['Gender', student.gender ?? '—'],
    ['Attendance', `${student.attendance.toFixed(1)}%`],
    ['Study Hours', `${student.study_hours.toFixed(1)} hrs/day`],
    ['Sleep Hours', `${student.sleep_hours.toFixed(1)} hrs`],
    ['Internal Marks', student.internal_marks.toFixed(1)],
    ['Assignment Score', student.assignment_score.toFixed(1)],
    ['Previous Exam Score', student.previous_exam_score.toFixed(1)],
    ['Midterm Score', student.midterm_score.toFixed(1)],
    ['Participation', student.participation.toFixed(1)],
  ]

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Final Result</p>
      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-5 ${student.final_result === 'pass' ? 'bg-indigo5 text-white' : 'bg-wine3 text-white'}`}>
        {student.final_result === 'pass' ? 'Pass' : 'Fail'}
      </span>

      <div className="grid grid-cols-2 gap-3 mb-5 text-sm">
        <div className="bg-paper rounded px-3 py-2">
          <p className="text-ink/40 text-xs">Academic Average</p>
          <p className="text-ink font-medium">{student.academic_average.toFixed(1)}</p>
        </div>
        <div className="bg-paper rounded px-3 py-2">
          <p className="text-ink/40 text-xs">Study Engagement</p>
          <p className="text-ink font-medium">{student.study_engagement.toFixed(1)}</p>
        </div>
        <div className="bg-paper rounded px-3 py-2 col-span-2">
          <p className="text-ink/40 text-xs">Attendance Category</p>
          <p className="text-ink font-medium">{attendanceCategory(student.attendance)}</p>
        </div>
      </div>

      <div className="space-y-2">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
