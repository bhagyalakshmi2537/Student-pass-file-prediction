import React from 'react'

export default function PredictionResult({ result, innerRef }) {
  if (!result) {
    return (
      <div className="h-full min-h-[240px] bg-white rounded-lg border border-black/5 border-dashed flex items-center justify-center text-ink/40 text-sm p-6 text-center">
        Fill in the form and click Predict Result to see a result here.
      </div>
    )
  }

  const { probability, willPass, input, threshold, modelLabel, interpretation } = result
  const pct = (probability * 100).toFixed(1)

  return (
    <div ref={innerRef} className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Prediction Result</p>
      <p className={`font-display text-3xl mb-1 ${willPass ? 'text-indigo5' : 'text-wine3'}`}>
        {willPass ? 'Likely to Pass' : 'Likely to Fail'}
      </p>
      <p className="text-xs text-ink/40 mb-5">Model prediction from {modelLabel} — not a guaranteed outcome.</p>

      <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
        <div className="bg-paper rounded px-3 py-2">
          <p className="text-ink/40 text-xs">Pass Probability</p>
          <p className="text-indigo5 font-medium">{pct}%</p>
        </div>
        <div className="bg-paper rounded px-3 py-2">
          <p className="text-ink/40 text-xs">Fail Probability</p>
          <p className="text-wine3 font-medium">{(100 - pct).toFixed(1)}%</p>
        </div>
      </div>

      <div className="w-full h-2.5 bg-black/5 rounded-full overflow-hidden mb-1">
        <div
          className={`h-full rounded-full transition-all duration-500 ${willPass ? 'bg-indigo5' : 'bg-wine3'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <p className="text-xs text-ink/40 mb-6">Classification threshold: {(threshold * 100).toFixed(0)}%</p>

      <div className="bg-paper rounded-md p-4 mb-5">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-1">Interpretation</p>
        <p className="text-sm text-ink font-medium">{interpretation}</p>
        <p className="text-xs text-ink/40 mt-1">Based on the submitted academic indicators — not a guaranteed outcome.</p>
      </div>

      <div className="space-y-2">
        {[
          ['Attendance', `${input.attendance}%`],
          ['Study Hours', `${input.study_hours} hrs/day`],
          ['Academic Average', input.academic_average.toFixed(1)],
        ].map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
