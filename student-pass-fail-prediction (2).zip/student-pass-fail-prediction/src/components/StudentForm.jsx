import React, { useState } from 'react'

const DEFAULTS = {
  attendance: 75,
  study_hours: 3.5,
  internal_marks: 60,
  assignment_score: 65,
  previous_exam_score: 60,
  midterm_score: 58,
  participation: 60,
  sleep_hours: 6.5,
}

const FIELDS = [
  ['attendance', 'Attendance (%)', 0, 100, 1],
  ['study_hours', 'Study Hours (per day)', 0, 12, 0.5],
  ['internal_marks', 'Internal Marks', 0, 100, 1],
  ['assignment_score', 'Assignment Score', 0, 100, 1],
  ['previous_exam_score', 'Previous Exam Score', 0, 100, 1],
  ['midterm_score', 'Midterm Score', 0, 100, 1],
  ['participation', 'Participation', 0, 100, 1],
  ['sleep_hours', 'Sleep Hours (per day)', 0, 12, 0.5],
]

export default function StudentForm({ modelKey, onModelChange, onSubmit, disabled }) {
  const [form, setForm] = useState(DEFAULTS)

  const handleChange = (field, value) => setForm((f) => ({ ...f, [field]: value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-black/5 p-6 space-y-5">
      <div>
        <label className="text-sm text-ink/70 block mb-1">Model</label>
        <select
          value={modelKey}
          onChange={(e) => onModelChange(e.target.value)}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="logistic-regression">Logistic Regression</option>
          <option value="decision-tree">Decision Tree</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {FIELDS.map(([key, label, min, max, step]) => (
          <div key={key}>
            <label className="text-xs text-ink/60 block mb-1">{label}</label>
            <input
              type="number"
              min={min} max={max} step={step}
              value={form[key]}
              onChange={(e) => handleChange(key, Number(e.target.value))}
              className="w-full border border-black/10 rounded-md px-2.5 py-1.5 text-sm"
            />
          </div>
        ))}
      </div>

      <button
        type="submit"
        disabled={disabled}
        className="w-full bg-ink text-white rounded-md py-2.5 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink/90 transition-colors"
      >
        {disabled ? 'Training model…' : 'Predict Result'}
      </button>
    </form>
  )
}
