import React, { useMemo, useState } from 'react'

const PAGE_SIZE = 10

const COLUMNS = [
  { key: 'student_id', label: 'Student ID' },
  { key: 'attendance', label: 'Attendance' },
  { key: 'study_hours', label: 'Study Hours' },
  { key: 'internal_marks', label: 'Internal Marks' },
  { key: 'assignment_score', label: 'Assignment' },
  { key: 'previous_exam_score', label: 'Prev. Exam' },
  { key: 'midterm_score', label: 'Midterm' },
  { key: 'final_result', label: 'Result' },
]

export default function StudentTable({ students, onSelect, selectedId }) {
  const [search, setSearch] = useState('')
  const [resultFilter, setResultFilter] = useState('all')
  const [sortKey, setSortKey] = useState('student_id')
  const [sortDir, setSortDir] = useState('asc')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    let result = students
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      result = result.filter((s) => String(s.student_id).toLowerCase().includes(q))
    }
    if (resultFilter !== 'all') result = result.filter((s) => s.final_result === resultFilter)

    return [...result].sort((a, b) => {
      const av = a[sortKey]
      const bv = b[sortKey]
      const diff = typeof av === 'string' ? av.localeCompare(bv) : av - bv
      return sortDir === 'asc' ? diff : -diff
    })
  }, [students, search, resultFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else { setSortKey(key); setSortDir('asc') }
    setPage(1)
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 p-5 min-w-0">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <input
          type="text"
          placeholder="Search by Student ID"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          className="flex-1 border border-black/10 rounded-md px-3 py-2 text-sm min-w-0"
        />
        <select value={resultFilter} onChange={(e) => { setResultFilter(e.target.value); setPage(1) }} className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Results</option>
          <option value="pass">Pass</option>
          <option value="fail">Fail</option>
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[700px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              {COLUMNS.map((col) => (
                <th key={col.key} onClick={() => toggleSort(col.key)} className="py-2 pr-4 cursor-pointer select-none whitespace-nowrap">
                  {col.label}{sortKey === col.key ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((s) => (
              <tr
                key={s.student_id}
                onClick={() => onSelect(s)}
                className={`border-b border-black/5 last:border-0 cursor-pointer hover:bg-black/[0.02] ${selectedId === s.student_id ? 'bg-black/[0.03]' : ''}`}
              >
                <td className="py-2 pr-4 whitespace-nowrap">{s.student_id}</td>
                <td className="py-2 pr-4">{s.attendance.toFixed(1)}%</td>
                <td className="py-2 pr-4">{s.study_hours.toFixed(1)}</td>
                <td className="py-2 pr-4">{s.internal_marks.toFixed(1)}</td>
                <td className="py-2 pr-4">{s.assignment_score.toFixed(1)}</td>
                <td className="py-2 pr-4">{s.previous_exam_score.toFixed(1)}</td>
                <td className="py-2 pr-4">{s.midterm_score.toFixed(1)}</td>
                <td className="py-2 pr-4">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${s.final_result === 'pass' ? 'bg-indigo5/10 text-indigo5' : 'bg-wine3/10 text-wine3'}`}>
                    {s.final_result === 'pass' ? 'Pass' : 'Fail'}
                  </span>
                </td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr><td colSpan={COLUMNS.length} className="py-6 text-center text-ink/40">No students match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4 text-sm text-ink/50">
        <span>{filtered.length} students</span>
        <div className="flex items-center gap-2">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={currentPage <= 1} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Prev</button>
          <span>{currentPage} / {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Next</button>
        </div>
      </div>
    </div>
  )
}
